package com.devsu.hackerearth.backend.account.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

        private final TransactionRepository transactionRepository;
        private final AccountRepository accountRepository;

        public TransactionServiceImpl(TransactionRepository transactionRepository,
                        AccountRepository accountRepository) {
                this.transactionRepository = transactionRepository;
                this.accountRepository = accountRepository;
        }

        @Override
        public List<TransactionDto> getAll() {
                // Get all transactions
                return transactionRepository.findAll()
                                .stream()
                                .map(tx -> new TransactionDto(
                                                tx.getId(),
                                                tx.getDate(),
                                                tx.getType(),
                                                tx.getAmount(),
                                                tx.getBalance(),
                                                tx.getAccountId()))
                                .collect(Collectors.toList());
        }

        @Override
        public TransactionDto getById(Long id) {
                // Get transactions by id
                Transaction tx = transactionRepository.findById(id)
                                .orElseThrow(() -> new RuntimeException("Transaccion no encontrada"));
                return new TransactionDto(
                                tx.getId(),
                                tx.getDate(),
                                tx.getType(),
                                tx.getAmount(),
                                tx.getBalance(),
                                tx.getAccountId());
        }

        @Override
        public TransactionDto create(TransactionDto transactionDto) {
                // Create transaction

                // Buscar la cuenta asociada
                Account account = accountRepository.findById(transactionDto.getAccountId())
                                .orElseThrow(() -> new RuntimeException("Cuenta no encontrada"));

                // Obtener el ultimo balance de la cuenta
                Double lastBalance = transactionRepository.findTopByAccountIdOrderByDateDesc(account.getId())
                                .map(Transaction::getBalance)
                                .orElse(account.getInitialAmount());

                // Calcular nuevo saldo
                double nuevoSaldo = lastBalance + transactionDto.getAmount();

                // Validar saldo disponible
                if (nuevoSaldo < 0) {
                        throw new RuntimeException("Saldo no disponible");
                }

                Transaction tx = new Transaction();
                tx.setDate(new Date());
                tx.setType(transactionDto.getType());
                tx.setAmount(transactionDto.getAmount());
                tx.setBalance(nuevoSaldo);
                tx.setAccountId(account.getId());
                tx.setId(transactionDto.getId());

                Transaction saved = transactionRepository.save(tx);

                // Retornar DTO
                return new TransactionDto(
                                saved.getId(),
                                saved.getDate(),
                                saved.getType(),
                                saved.getAmount(),
                                saved.getBalance(),
                                saved.getAccountId());
        }

        @Override
        public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
                        Date dateTransactionEnd) {
                // Report
                // Busacr todas la cuentas asociadas
                List<Account> accounts = accountRepository.findByClientId(clientId);
                List<BankStatementDto> report = new ArrayList<>();
            
                for (Account acc : accounts) {
                     // Buscar transacciones de la cuenta en el rango de fechas
                    List<Transaction> transactions = transactionRepository
                            .findByAccountIdAndDateBetween(acc.getId(), dateTransactionStart, dateTransactionEnd);
            
                     // Armar el DTO del estado de cuenta
                    BankStatementDto dto = new BankStatementDto();
                    dto.setClient("Cliente " + acc.getClientId());
                    dto.setAccountNumber(acc.getNumber());
                    dto.setAccountType(acc.getType());
                    dto.setInitialAmount(acc.getInitialAmount());
                    dto.setIsActive(acc.getIsActive());
                    dto.setTransactions(transactions.stream()
                            .map(tx -> new TransactionDto(
                                    tx.getId(),
                                    tx.getDate(),
                                    tx.getType(),
                                    tx.getAmount(),
                                    tx.getBalance(),
                                    tx.getAccountId()))
                            .collect(Collectors.toList()));
            
                    report.add(dto);
                }
            
                return report;
        }

        @Override
        public TransactionDto getLastByAccountId(Long accountId) {
                // If you need it
                Transaction tx = transactionRepository.findTopByAccountIdOrderByDateDesc(accountId)
                                .orElseThrow(() -> new RuntimeException("No hay transacciones para esta cuenta"));
                return new TransactionDto(
                                tx.getId(),
                                tx.getDate(),
                                tx.getType(),
                                tx.getAmount(),
                                tx.getBalance(),
                                tx.getAccountId());
        }

}
