package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public List<AccountDto> getAll() {
        // Get all accounts
        return accountRepository.findAll()
                .stream()
                .map(acc -> new AccountDto(
                        acc.getId(),
                        acc.getNumber(),
                        acc.getType(),
                        acc.getInitialAmount(),
                        acc.getIsActive(),
                        acc.getClientId()))
                .collect(Collectors.toList());
    }

    @Override
    public AccountDto getById(Long id) {
        // Get accounts by id
        Account acc = accountRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cuenta no encontrada"));
        return new AccountDto(
                acc.getId(),
                acc.getNumber(),
                acc.getType(),
                acc.getInitialAmount(),
                acc.getIsActive(),
                acc.getClientId());
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
        // Create account
        Account acc = new Account(
                accountDto.getNumber(),
                accountDto.getType(),
                accountDto.getInitialAmount(),
                accountDto.getIsActive(),
                accountDto.getClientId(),
                accountDto.getId());
        Account saved = accountRepository.save(acc);
        return new AccountDto(
                saved.getId(),
                saved.getNumber(),
                saved.getType(),
                saved.getInitialAmount(),
                saved.getIsActive(),
                saved.getClientId());
    }

    @Override
    public AccountDto update(AccountDto accountDto) {
        // Update account
        Account acc = accountRepository.findById(accountDto.getId())
                .orElseThrow(() -> new RuntimeException("Cuenta no encontrada"));
        acc.setNumber(accountDto.getNumber());
        acc.setType(accountDto.getType());
        acc.setInitialAmount(accountDto.getInitialAmount());
        acc.setIsActive(accountDto.getIsActive());
        acc.setClientId(accountDto.getClientId());
        Account updated = accountRepository.save(acc);
        return new AccountDto(
                updated.getId(),
                updated.getNumber(),
                updated.getType(),
                updated.getInitialAmount(),
                updated.getIsActive(),
                updated.getClientId());
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        // Partial update account
        Account acc = accountRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cuenta no encontrada"));
        if (partialAccountDto.getNumber() != null)
            acc.setNumber(partialAccountDto.getNumber());
        if (partialAccountDto.getType() != null)
            acc.setType(partialAccountDto.getType());
        if (partialAccountDto.getInitialAmount() != null)
            acc.setInitialAmount(partialAccountDto.getInitialAmount());
        if (partialAccountDto.getIsActive() != null)
            acc.setIsActive(partialAccountDto.getIsActive());
        Account updated = accountRepository.save(acc);
        return new AccountDto(
                updated.getId(),
                updated.getNumber(),
                updated.getType(),
                updated.getInitialAmount(),
                updated.getIsActive(),
                updated.getClientId());
    }

    @Override
    public void deleteById(Long id) {
        // Delete account
        accountRepository.deleteById(id);
    }

}
