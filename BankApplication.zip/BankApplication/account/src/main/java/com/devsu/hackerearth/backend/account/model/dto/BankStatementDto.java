package com.devsu.hackerearth.backend.account.model.dto;

import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BankStatementDto {
    
	private Date date;
	private String client;
	private String accountNumber;
	private String accountType;
	private Double initialAmount;
    private Boolean isActive;
	private String transactionType;
	private Double amount;
	private Double balance;
	private List<TransactionDto> transactions;
}
