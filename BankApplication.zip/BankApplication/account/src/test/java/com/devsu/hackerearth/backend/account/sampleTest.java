package com.devsu.hackerearth.backend.account;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import com.devsu.hackerearth.backend.account.model.Account;

@SpringBootTest
@AutoConfigureMockMvc
public class sampleTest {

	@Autowired
	private MockMvc mockMvc;

	/*
	 * @Test
	 * void createAccountTest() {
	 * // Arrange
	 * AccountDto newAccount = new AccountDto(1L, "number", "savings", 0.0, true,
	 * 1L);
	 * AccountDto createdAccount = new AccountDto(1L, "number", "savings", 0.0,
	 * true, 1L);
	 * when(accountService.create(newAccount)).thenReturn(createdAccount);
	 * 
	 * // Act
	 * ResponseEntity<AccountDto> response = accountController.create(newAccount);
	 * 
	 * // Assert
	 * assertEquals(HttpStatus.CREATED, response.getStatusCode());
	 * assertEquals(createdAccount, response.getBody());
	 * }
	 */

	// F5: Pruebas unotaria
	@Test
	void accountEntityTest() {
		Account account = new Account("12345", "Ahorro", 1000.0, true, Long.parseLong("1"), Long.parseLong("10"));

		assertEquals("12345", account.getNumber());
		assertEquals("Ahorro", account.getType());
		assertEquals(1000.0, account.getInitialAmount());
		assertTrue(account.getIsActive());
	}

	// F6: Prueba de integrcion para el POST
	@Test
	void createAccountTest() throws Exception {
		String json = "{ \"number\":\"12345\", \"type\":\"Ahorro\", " +
				"\"initialAmount\":1000.0, \"isActive\":true, \"clientId\":1 }";

		mockMvc.perform(post("/api/accounts")
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.number").value("12345"))
				.andExpect(jsonPath("$.type").value("Ahorro"))
				.andExpect(jsonPath("$.initialAmount").value(1000.0))
				.andExpect(jsonPath("$.isActive").value(true));
	}
}
