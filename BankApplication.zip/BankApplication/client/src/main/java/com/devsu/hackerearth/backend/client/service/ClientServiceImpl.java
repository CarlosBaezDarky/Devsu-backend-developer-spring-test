package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	@Override
	public List<ClientDto> getAll() {
		// Get all clients
		return clientRepository.findAll()
				.stream()
				.map(c -> new ClientDto(
						c.getId(),
						c.getDni(),
						c.getName(),
						c.getPassword(),
						c.getGender(),
						c.getAge(),
						c.getAddress(),
						c.getPhone(),
						c.getIsActive()))
				.collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(Long id) {
		// Get clients by id
		Client c = clientRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
		return new ClientDto(
				c.getId(),
				c.getDni(),
				c.getName(),
				c.getPassword(),
				c.getGender(),
				c.getAge(),
				c.getAddress(),
				c.getPhone(),
				c.getIsActive());
	}

	@Override
	public ClientDto create(ClientDto clientDto) {
		// Create client
		Client c = new Client(
				clientDto.getId(),
				clientDto.getName(),
				clientDto.getDni(),
				clientDto.getGender(),
				clientDto.getAge(),
				clientDto.getAddress(),
				clientDto.getPhone(),
				clientDto.getPassword(),
				clientDto.getIsActive());
		Client saved = clientRepository.save(c);
		return new ClientDto(
				saved.getId(),
				saved.getDni(),
				saved.getName(),
				saved.getPassword(),
				saved.getGender(),
				saved.getAge(),
				saved.getAddress(),
				saved.getPhone(),
				saved.getIsActive());
	}

	@Override
	public ClientDto update(ClientDto clientDto) {
		// Update client
		Client c = clientRepository.findById(clientDto.getId())
				.orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
		c.setName(clientDto.getName());
		c.setDni(clientDto.getDni());
		c.setGender(clientDto.getGender());
		c.setAge(clientDto.getAge());
		c.setAddress(clientDto.getAddress());
		c.setPhone(clientDto.getPhone());
		c.setPassword(clientDto.getPassword());
		c.setIsActive(clientDto.getIsActive());
		Client updated = clientRepository.save(c);
		return new ClientDto(
				updated.getId(),
				updated.getDni(),
				updated.getName(),
				updated.getPassword(),
				updated.getGender(),
				updated.getAge(),
				updated.getAddress(),
				updated.getPhone(),
				updated.getIsActive());
	}

	@Override
	public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
		// Partial update account
		Client c = clientRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Cliente no encontrado"));
		if (partialClientDto.getName() != null)
			c.setName(partialClientDto.getName());
		if (partialClientDto.getDni() != null)
			c.setDni(partialClientDto.getDni());
		if (partialClientDto.getGender() != null)
			c.setGender(partialClientDto.getGender());
		if (partialClientDto.getAge() != null)
			c.setAge(partialClientDto.getAge());
		if (partialClientDto.getAddress() != null)
			c.setAddress(partialClientDto.getAddress());
		if (partialClientDto.getPhone() != null)
			c.setPhone(partialClientDto.getPhone());
		if (partialClientDto.getPassword() != null)
			c.setPassword(partialClientDto.getPassword());
		if (partialClientDto.getIsActive() != null)
			c.setIsActive(partialClientDto.getIsActive());
		Client updated = clientRepository.save(c);
		return new ClientDto(
				updated.getId(),
				updated.getDni(),
				updated.getName(),
				updated.getPassword(),
				updated.getGender(),
				updated.getAge(),
				updated.getAddress(),
				updated.getPhone(),
				updated.getIsActive());
	}

	@Override
	public void deleteById(Long id) {
		// Delete client
		clientRepository.deleteById(id);
	}
}
