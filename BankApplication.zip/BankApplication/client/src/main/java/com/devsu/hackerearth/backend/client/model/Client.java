package com.devsu.hackerearth.backend.client.model;

import javax.persistence.Entity;

@Entity
public class Client extends Person {
	private String password;
	private Boolean isActive;

	// Constructor vacio
	public Client() {
	}

	// Constructor con parametros
	public Client(Long id, String name, String dni, String gender, int age, String address, String phone,
			String password,
			Boolean isActive) {
		super(id, name, dni, gender, age, address, phone);
		this.password = password;
		this.isActive = isActive;
	}

	// Getters y Setters
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
}
