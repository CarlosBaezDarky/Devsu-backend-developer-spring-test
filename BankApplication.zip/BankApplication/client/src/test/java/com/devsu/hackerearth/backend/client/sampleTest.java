package com.devsu.hackerearth.backend.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.http.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import com.devsu.hackerearth.backend.client.model.Client;

@SpringBootTest
@AutoConfigureMockMvc
public class sampleTest {

    @Autowired
    private MockMvc mockMvc;

    // F5: Prueba unitaria de la entidad Client
    /*
     * @Test
     * void createClientTest() {
     * // Arrange
     * Client client = new Client(Long.parseLong("1"), "Carlos", "123456", "M", 30,
     * "Santo Domingo", "8095551234", "secret", true);
     * ClientDto newClient = new ClientDto(client.getId(), client.getName(),
     * client.getDni(), client.getPassword(),client.getGender(), client.getAge(),
     * client.getAddress(), client.getPhone(), client.getIsActive());
     * 
     * when(clientService.create(newClient)).thenReturn(newClient);
     * // Act
     * ResponseEntity<ClientDto> response = clientController.create(newClient);
     * 
     * // Assert
     * assertEquals(HttpStatus.CREATED, response.getStatusCode());
     * assertEquals(newClient, response.getBody());
     * assertEquals("Carlos", newClient.getName());
     * assertEquals("123456", newClient.getDni());
     * }
     */
    @Test
    void clientEntityTest() {
        Client client = new Client(Long.parseLong("1"), "Carlos", "123456", "M", 30, "Santo Domingo", "8095551234",
                "secret", true);

        assertEquals("Carlos", client.getName());
        assertEquals("123456", client.getDni());
        assertTrue(client.getIsActive());
    }

    // F6 Pruebas de integracion Post
    @Test
    void createClientTest() throws Exception {
        String json = "{ \"name\":\"Carlos\", \"dni\":\"123456\", \"gender\":\"M\", \"age\":30, " +
                "\"address\":\"Santo Domingo\", \"phone\":\"8095551234\", " +
                "\"password\":\"secret\", \"isActive\":true }";

        mockMvc.perform(post("/api/clients")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").value("Carlos"))
                .andExpect(jsonPath("$.dni").value("123456"));
    }
}
